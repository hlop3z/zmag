# -*- coding: utf-8 -*-
""" { Command-Line-Interface }
    Main File.
"""
from zmag.app import Controller

if __name__ == "__main__":
    Controller.cli()
