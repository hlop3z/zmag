import zmag

app = zmag.App()

if __name__ == "__main__":
    app.cli()
