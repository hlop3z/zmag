# -*- coding: utf-8 -*-
"""
    { Schema }
"""

import zmag


# Create your <schema> here.
@zmag.schema
class Schema:
    types = []
