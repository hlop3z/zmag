# -*- coding: utf-8 -*-
"""
    { Manager }
"""

import zmag


# Manager your <types> here.
# Example: `Author = zmag.type("author")`
