# -*- coding: utf-8 -*-
"""
Commands
"""

# Read the Docs
# https://hlop3z.github.io/zmag/server/commands

import zmag

# Create <Commands> here.
