# -*- coding: utf-8 -*-
"""
Pushers
"""

# Read the Docs
# https://hlop3z.github.io/zmag/server/streamer/

import zmag

# Create Streamer <Pushers> here.
