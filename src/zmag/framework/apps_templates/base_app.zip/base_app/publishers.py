# -*- coding: utf-8 -*-
"""
Publishers
"""

# Read the Docs
# https://hlop3z.github.io/zmag/server/forwarder/

import zmag

# Create Forwarder <Publishers> here.
