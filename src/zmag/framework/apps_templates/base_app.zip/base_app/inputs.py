# -*- coding: utf-8 -*-
"""
Forms
"""

# Read the Docs
# https://hlop3z.github.io/zmag/server/graphql/inputs/

import zmag


# Create your <Inputs> here.
