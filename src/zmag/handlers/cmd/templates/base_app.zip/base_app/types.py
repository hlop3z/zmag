# -*- coding: utf-8 -*-
"""
    { Types } for GraphQL
"""

from typing import Optional

import zmag

# Create your <types> here.
